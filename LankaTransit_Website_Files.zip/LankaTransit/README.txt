LankaTransit website
====================

Files:
- index.html
- style.css
- script.js

How to run:
1. Keep all three files in the same folder.
2. Open the folder in Visual Studio Code.
3. Install the "Live Server" extension if you have not already.
4. Right-click index.html > Open with Live Server.
5. Allow location permission only if you want to use the "My location" feature.

Notes:
- The interactive map uses Leaflet and OpenStreetMap.
- Railway/road/bus-stop/airport/port map features are requested from the OpenStreetMap Overpass API when a layer is selected.
- The Overpass service may be slow or temporarily unavailable. Map feature coverage depends on community-mapped data.
- The highlighted key transport hubs are reference points for orientation, not confirmation of current operational status.
- Route directions open OpenStreetMap's external directions page; they are not public-transport routing, live traffic, ticket booking or timetable integration.
- External service links are provided for convenience. No booking/API integration is claimed.
- Internet access is required for map tiles, map data, fonts and external links.
