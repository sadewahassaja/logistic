// LankaTransit — map features are queried from OpenStreetMap's Overpass API.
const map = L.map('map', { scrollWheelZoom: true }).setView([7.8731, 80.7718], 7);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19,
  attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a> contributors'
}).addTo(map);

const layerGroups = {
  railway: L.featureGroup().addTo(map),
  road: L.featureGroup(),
  bus: L.featureGroup(),
  airport: L.featureGroup(),
  port: L.featureGroup()
};
const keyPlaces = [
  {name:'Colombo Fort Railway Station', coords:[6.9344,79.8500], type:'railway'},
  {name:'Kandy Railway Station', coords:[7.2906,80.6337], type:'railway'},
  {name:'Galle Railway Station', coords:[6.0367,80.2169], type:'railway'},
  {name:'Jaffna Railway Station', coords:[9.6615,80.0255], type:'railway'},
  {name:'Badulla Railway Station', coords:[6.9934,81.0550], type:'railway'},
  {name:'Bandaranaike International Airport', coords:[7.1808,79.8841], type:'airport'},
  {name:'Mattala Rajapaksa International Airport', coords:[6.2845,81.1241], type:'airport'},
  {name:'Colombo Ratmalana Airport', coords:[6.8219,79.8862], type:'airport'},
  {name:'Colombo Port', coords:[6.9497,79.8428], type:'port'},
  {name:'Hambantota Port', coords:[6.1239,81.1025], type:'port'},
  {name:'Trincomalee Port', coords:[8.5680,81.2330], type:'port'},
  {name:'Galle Port', coords:[6.0300,80.2200], type:'port'}
];
const colors = {railway:'#d78a2c',road:'#267bc2',bus:'#159b83',airport:'#7958c7',port:'#1595a9'};
const icons = {railway:'🚆',road:'🛣️',bus:'🚌',airport:'✈️',port:'⚓'};
keyPlaces.forEach(p => {
  const marker = L.circleMarker(p.coords,{radius:7,color:'#fff',weight:2,fillColor:colors[p.type],fillOpacity:1});
  marker.bindPopup(`<strong>${p.name}</strong><br><small>Key reference location · verify operational details with operator</small>`);
  marker.addTo(layerGroups[p.type]);
});

let activeLayer = 'all';
let loaded = false;
const status = document.getElementById('mapStatus');
function setStatus(message){ status.textContent = message; }

function overpassQuery(layer){
  const selectors = {
    railway: 'way["railway"~"rail|light_rail|subway"](5.7,79.3,10.1,82.1);node["railway"="station"](5.7,79.3,10.1,82.1);',
    road: 'way["highway"~"motorway|trunk|primary|secondary"](5.7,79.3,10.1,82.1);',
    bus: 'node["highway"="bus_stop"](5.7,79.3,10.1,82.1);node["public_transport"="platform"]["bus"="yes"](5.7,79.3,10.1,82.1);',
    airport: 'node["aeroway"~"aerodrome|terminal"](5.7,79.3,10.1,82.1);',
    port: 'node["harbour"="yes"](5.7,79.3,10.1,82.1);node["seamark:type"="harbour"](5.7,79.3,10.1,82.1);'
  };
  return `[out:json][timeout:25];(${selectors[layer]});out geom;`;
}
async function loadLayer(layer){
  if(layerGroups[layer].getLayers().length) return;
  setStatus(`Loading ${layer} data…`);
  try{
    const response = await fetch('https://overpass-api.de/api/interpreter',{
      method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},
      body:'data='+encodeURIComponent(overpassQuery(layer))
    });
    if(!response.ok) throw new Error('Map data service unavailable');
    const data = await response.json();
    const group = layerGroups[layer];
    data.elements.forEach(el=>{
      const tags = el.tags || {};
      const name = tags.name || tags.ref || `${layer} feature`;
      const popup = `<strong>${escapeHTML(name)}</strong><br><small>OpenStreetMap mapped feature · verify current status</small>`;
      if(el.type==='node' && el.lat && el.lon){
        L.circleMarker([el.lat,el.lon],{radius:5,color:'#fff',weight:1,fillColor:colors[layer],fillOpacity:.95}).bindPopup(popup).addTo(group);
      }else if(el.geometry && el.geometry.length){
        const coords = el.geometry.map(pt=>[pt.lat,pt.lon]);
        L.polyline(coords,{color:colors[layer],weight:layer==='road'?2.5:3,opacity:.72}).bindPopup(popup).addTo(group);
      }
    });
    setStatus(`${data.elements.length.toLocaleString()} ${layer} features loaded`);
  }catch(error){
    setStatus('Some map data could not be loaded. Try again later.');
    console.warn('Overpass query failed:',error);
  }
}
function escapeHTML(str){return String(str).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function showLayer(layer){
  activeLayer=layer;
  Object.entries(layerGroups).forEach(([name,group])=>{
    if(layer==='all'||layer===name){if(!map.hasLayer(group))group.addTo(map);}else if(map.hasLayer(group))map.removeLayer(group);
  });
  document.querySelectorAll('.layer-btn').forEach(btn=>btn.classList.toggle('active',btn.dataset.layer===layer));
  if(layer==='all') Object.keys(layerGroups).forEach(loadLayer);
  else loadLayer(layer);
}
document.querySelectorAll('.layer-btn').forEach(btn=>btn.addEventListener('click',()=>showLayer(btn.dataset.layer)));
document.querySelectorAll('[data-layer-jump]').forEach(btn=>btn.addEventListener('click',()=>{
  document.getElementById('explore').scrollIntoView({behavior:'smooth'});
  showLayer(btn.dataset.layerJump);
}));
document.querySelectorAll('.place-link').forEach(btn=>btn.addEventListener('click',()=>{
  const place=btn.dataset.place;
  const match=keyPlaces.find(p=>p.name.toLowerCase().includes(place.toLowerCase()));
  if(match){map.setView(match.coords,12);layerGroups[match.type].eachLayer(l=>{if(l.getLatLng&&l.getLatLng().equals(L.latLng(match.coords)))l.openPopup();});}
  else geocode(place);
}));
async function geocode(query){
  if(!query.trim()) return;
  setStatus('Searching location…');
  try{
    const url=`https://nominatim.openstreetmap.org/search?format=json&countrycodes=lk&limit=1&q=${encodeURIComponent(query+', Sri Lanka')}`;
    const res=await fetch(url,{headers:{'Accept-Language':'en'}});
    const results=await res.json();
    if(!results.length){setStatus('No matching Sri Lankan location found.');return null;}
    const p=results[0], coords=[Number(p.lat),Number(p.lon)];
    map.setView(coords,13);L.marker(coords).addTo(map).bindPopup(`<strong>${escapeHTML(p.display_name.split(',')[0])}</strong><br><small>Search result from OpenStreetMap</small>`).openPopup();
    setStatus('Location found');return coords;
  }catch(e){setStatus('Location search unavailable.');return null;}
}
document.getElementById('searchForm').addEventListener('submit',async e=>{
  e.preventDefault();const q=document.getElementById('locationSearch').value;
  if(q.trim()){document.getElementById('explore').scrollIntoView({behavior:'smooth'});await geocode(q);}
});
document.getElementById('routeBtn').addEventListener('click',()=>{
  const from=document.getElementById('fromLocation').value.trim();
  const to=document.getElementById('toLocation').value.trim();
  if(!from||!to){setStatus('Enter both a starting point and destination.');return;}
  const url=`https://www.openstreetmap.org/directions?engine=fossgis_osrm_car&route=${encodeURIComponent(from)}%3B${encodeURIComponent(to)}`;
  window.open(url,'_blank','noopener');
});
document.getElementById('locateBtn').addEventListener('click',()=>{
  if(!navigator.geolocation){setStatus('Location is not supported by this browser.');return;}
  setStatus('Finding your location…');
  navigator.geolocation.getCurrentPosition(pos=>{
    const coords=[pos.coords.latitude,pos.coords.longitude];map.setView(coords,14);
    L.marker(coords).addTo(map).bindPopup('Your current location').openPopup();setStatus('Your location shown');
  },()=>setStatus('Location permission was not granted.'),{enableHighAccuracy:true,timeout:10000});
});
document.getElementById('menuToggle').addEventListener('click',()=>document.getElementById('mainNav').classList.toggle('open'));
document.querySelectorAll('.main-nav a').forEach(a=>a.addEventListener('click',()=>document.getElementById('mainNav').classList.remove('open')));

// Load the railway layer first; other layers load when selected or when "All" is chosen.
loadLayer('railway');
